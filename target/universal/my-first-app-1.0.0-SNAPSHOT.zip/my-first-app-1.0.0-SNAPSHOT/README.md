使用Play FrameWork 搭建Ec2 admin Server 
Create a EC2 Admin Server by Play FrameWork

此Server提供Restful Api, 讓其他不具ec2 control 權限的instance能夠改變自己的狀態。
The server provide some api for other ec2 instances, they can  access api to change status or other operation the server provided



